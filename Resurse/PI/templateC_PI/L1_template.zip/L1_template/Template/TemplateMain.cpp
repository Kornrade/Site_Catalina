#include <cv.h>
#include <highgui.h>  // highgui.h face parte din OpenCV

using namespace cv;
using namespace std; 

void main( )
{
	char*imagine = "imag1.jpg";
	// incarca imagine folosind functia cvLoadImage
	IplImage*img = cvLoadImage(imagine);
	// IplImage = Intel Image Processing Library
	// IplImage este tipul variabilei; este o structura ce contine informatii despre imagine (size, color depth, etc.)
	/*typedef struct _IplImage {
		int                  nSize;	
		int                  ID;
		int                  nChannels;
		int                  alphaChannel;
		int                  depth;
		char                 colorModel[4];
		char                 channelSeq[4];
		int                  dataOrder;
		int                  origin;
		int                  align;
		int                  width;
		int                  height;
		struct _IplROI*      roi;
		struct _IplImage*    maskROI;
		void*                imageId;
		struct _IplTileInfo* tileInfo;
		int                  imageSize;
		char*                imageData;
		int                  widthStep;
		int                  BorderMode[4];
		int                  BorderConst[4];
		char*                imageDataOrigin;
		} ; */

    // un pixel este de tipul CvScalar
	// pentru a citi valoarea unui pixel se foloseste functia cvGet2D
	// pentru a seta valoarea unui pixel se foloseste functia cvSet2D
	CvScalar currPixel; 

	// imagine grayscale
	double mix;
	IplImage*imgGRAY = cvLoadImage(imagine);
    for( int y = 0; y < imgGRAY->height; y++ ) { 
        for( int x = 0; x<imgGRAY->width; x++ ) {
			currPixel = cvGet2D(img, y, x);	
		    mix = double(currPixel.val[0]*0.33 + currPixel.val[1]*0.33 + currPixel.val[2]*0.33);
			currPixel.val[0] = mix;
			currPixel.val[1] = mix;
			currPixel.val[2] = mix;
			cvSet2D(imgGRAY,y,x,currPixel);
		}
    }


	// afisare
	cvShowImage( "Imagine originala", img );   //afisare imagine                
    cvShowImage( "Imagine grayscale", imgGRAY);      
	cvWaitKey(0);  // se asteapta apasarea unei taste
	cvDestroyWindow( "Imagine originala" ); //inchiderea imaginii
	cvDestroyWindow( "Imagine grayscale" );

}//end main