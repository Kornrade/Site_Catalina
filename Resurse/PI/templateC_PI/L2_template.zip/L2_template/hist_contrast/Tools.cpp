#include "Tools.h"


void plotHist(int*histptr, int histSize, char*Name)
{
	//plot hist
	/// Establish the number of bins
	int hist_w = 512; int hist_h = 400;
	int bin_w = cvRound( (double) hist_w/histSize );
	int maxh = 0;
	for(int i=0;i<histSize;i++)
	{
		if(maxh<histptr[i])
			maxh = histptr[i];
	}
	double hfactor = 0.8*double(hist_h)/double(maxh);
	Mat histImage( hist_h, hist_w, CV_8UC3, Scalar( 255,255,255) );
	for( int i = 1; i < histSize; i++ )
	{
		line( histImage, Point( bin_w*(i-1), hist_h - cvRound((double)histptr[i-1]*hfactor) ) ,
                       Point( bin_w*(i), hist_h - cvRound((double)histptr[i]*hfactor) ),
                       Scalar( 255, 0, 0), 2, 8, 0  );
	}
	/// Display
	  imshow(Name,histImage);
}