#include "Tools.h"

void main( )
{
    char *imagine = "imagine1.jpg";
	//incarca imagine
	IplImage*img = cvLoadImage(imagine);

    // imagine grayscale
	CvScalar currPixel;
	double mix;
	IplImage*imgGRAY= cvLoadImage(imagine);
      for( int y = 0; y < imgGRAY->height; y++ ) { 
           for( int x = 0; x<imgGRAY->width; x++ ) {
			currPixel = cvGet2D(img, y, x);	
            mix = currPixel.val[0]*0.114 + currPixel.val[1]*0.587 + currPixel.val[2]*0.299;
			currPixel.val[0] = mix;
			currPixel.val[1] = mix;
			currPixel.val[2] = mix;
			cvSet2D(imgGRAY,y,x,currPixel);
		 }
      } 

    // calcul histograma imagine grayscale originala

	// modificare contrast

    
	// calcul histograma imagine grayscale cu contrast modificat
	    
	//plotHist(h, 256, "histograma");
    cvShowImage( "Imagine originala", img );   //afisare imagine 
    cvShowImage( "Imagine grayscale", imgGRAY); 
    
	cvWaitKey(0); 

    cvDestroyWindow( "Imagine originala" );    //inchiderea imaginii
	cvDestroyWindow( "Imagine grayscale" );
  
}
