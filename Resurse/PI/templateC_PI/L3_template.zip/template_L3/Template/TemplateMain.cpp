#include "Tools.h"

void main( )
{
	// incarca imagine
	char*imagine = "imagine4.png";
	IplImage*img = cvLoadImage(imagine);

	// imagine grayscale
	CvScalar currPixel;
	double mix;
	IplImage*imgGRAY = cvLoadImage(imagine);
    for( int y = 0; y < imgGRAY->height; y++ ) { 
        for( int x = 0; x<imgGRAY->width; x++ ) {
			currPixel = cvGet2D(img, y, x);	
		    mix = currPixel.val[0]*0.114 + currPixel.val[1]*0.587 + currPixel.val[2]*0.229;
			currPixel.val[0] = (int)mix;
			currPixel.val[1] = (int)mix;
			currPixel.val[2] = (int)mix;
			cvSet2D(imgGRAY,y,x,currPixel);
		}
    }

    // calculul histogramei pentru imaginea grayscale originala

	// histograma cumulativa

	// vectorul transformarii

	// modificarea imaginii conform vectorului transformarii

	// calcul histograma pentru imaginea grayscale obtinuta in urma egalizarii de histograma


	cvShowImage( "Imagine originala", img );  
	cvShowImage( "Imagine grayscale", imgGRAY); 
	// plotHist(h, 256, "historig");

	cvWaitKey(0);
	cvDestroyWindow( "Imagine originala" );      
	cvDestroyWindow( "Imagine grayscale" );        
	
}//end main