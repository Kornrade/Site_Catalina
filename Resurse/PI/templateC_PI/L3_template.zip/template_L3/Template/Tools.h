#include <cv.h>
#include <highgui.h>
#include <iostream>
#include <math.h>

using namespace cv;
using namespace std;

void plotHist(int*hist, int histSize, const string Name);